<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "funcionario".
 *
 * @property int $num_funcionario
 * @property string $nome
 * @property string $dt_nascimento
 * @property int $num_contribuinte
 * @property int $num_cc
 *
 * @property Reserva[] $reservas
 */
class Funcionario extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'funcionario';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['num_funcionario', 'nome', 'dt_nascimento', 'num_contribuinte', 'num_cc'], 'required'],
            [['num_funcionario', 'num_contribuinte', 'num_cc'], 'integer'],
            [['dt_nascimento'], 'safe'],
            [['nome'], 'string', 'max' => 100],
            [['num_funcionario'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'num_funcionario' => 'Num Funcionario',
            'nome' => 'Nome',
            'dt_nascimento' => 'Dt Nascimento',
            'num_contribuinte' => 'Num Contribuinte',
            'num_cc' => 'Num Cc',
        ];
    }

    /**
     * Gets query for [[Reservas]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getReservas()
    {
        return $this->hasMany(Reserva::className(), ['num_funcionario' => 'num_funcionario']);
    }
}
