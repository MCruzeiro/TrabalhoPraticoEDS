<?php

namespace app\models;

use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\Alojamento;

/**
 * AlojamentoSearch represents the model behind the search form of `app\models\Alojamento`.
 */
class AlojamentoSearch extends Alojamento
{
    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['cod_alojamento'], 'integer'],
            [['valor'], 'number'],
            [['rua', 'nPorta', 'cod_postal', 'nome', 'país'], 'safe'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Alojamento::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'cod_alojamento' => $this->cod_alojamento,
            'valor' => $this->valor,
        ]);

        $query->andFilterWhere(['like', 'rua', $this->rua])
            ->andFilterWhere(['like', 'nPorta', $this->nPorta])
            ->andFilterWhere(['like', 'cod_postal', $this->cod_postal])
            ->andFilterWhere(['like', 'nome', $this->nome])
            ->andFilterWhere(['like', 'país', $this->país]);

        return $dataProvider;
    }
}
