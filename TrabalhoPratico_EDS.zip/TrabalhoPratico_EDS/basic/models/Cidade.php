<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "cidade".
 *
 * @property int $cod_cidade
 * @property string $nome
 * @property float $valor
 * @property string $país
 *
 * @property CidadePacotes[] $cidadePacotes
 */
class Cidade extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'cidade';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['cod_cidade', 'nome', 'valor', 'país'], 'required'],
            [['cod_cidade'], 'integer'],
            [['valor'], 'number'],
            [['nome', 'país'], 'string', 'max' => 100],
            [['cod_cidade'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'cod_cidade' => 'Cod Cidade',
            'nome' => 'Nome',
            'valor' => 'Valor',
            'país' => 'País',
        ];
    }

    /**
     * Gets query for [[CidadePacotes]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCidadePacotes()
    {
        return $this->hasMany(CidadePacotes::className(), ['cod_cidade' => 'cod_cidade']);
    }
}
