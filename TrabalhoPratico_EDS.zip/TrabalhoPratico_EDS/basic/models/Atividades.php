<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "atividades".
 *
 * @property int $cod_atividade
 * @property string $nome
 * @property string $descrição
 * @property float $valor
 *
 * @property AtividadesPacotes[] $atividadesPacotes
 */
class Atividades extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'atividades';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['cod_atividade', 'nome', 'descrição', 'valor'], 'required'],
            [['cod_atividade'], 'integer'],
            [['valor'], 'number'],
            [['nome'], 'string', 'max' => 10],
            [['descrição'], 'string', 'max' => 500],
            [['cod_atividade'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'cod_atividade' => 'Cod Atividade',
            'nome' => 'Nome',
            'descrição' => 'Descrição',
            'valor' => 'Valor',
        ];
    }

    /**
     * Gets query for [[AtividadesPacotes]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getAtividadesPacotes()
    {
        return $this->hasMany(AtividadesPacotes::className(), ['cod_atividade' => 'cod_atividade']);
    }
}
