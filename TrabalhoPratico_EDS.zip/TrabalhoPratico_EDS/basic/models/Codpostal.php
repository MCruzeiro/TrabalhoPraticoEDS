<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "codpostal".
 *
 * @property string $codpostal
 * @property string $localidade
 *
 * @property Alojamento[] $alojamentos
 * @property Cliente[] $clientes
 */
class Codpostal extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'codpostal';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['codpostal', 'localidade'], 'required'],
            [['codpostal'], 'string', 'max' => 20],
            [['localidade'], 'string', 'max' => 200],
            [['codpostal'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'codpostal' => 'Codpostal',
            'localidade' => 'Localidade',
        ];
    }

    /**
     * Gets query for [[Alojamentos]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getAlojamentos()
    {
        return $this->hasMany(Alojamento::className(), ['cod_postal' => 'codpostal']);
    }

    /**
     * Gets query for [[Clientes]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getClientes()
    {
        return $this->hasMany(Cliente::className(), ['cod_postal' => 'codpostal']);
    }
}
