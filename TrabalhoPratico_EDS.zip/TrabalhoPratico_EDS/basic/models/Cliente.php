<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "cliente".
 *
 * @property int $num_cliente
 * @property string $nome
 * @property string $dt_nascimento
 * @property string $rua
 * @property string $nPorta
 * @property string $cod_postal
 * @property int $num_cc
 * @property string $email
 * @property int $telefone
 * @property int $num_contribuinte
 *
 * @property Codpostal $codPostal
 * @property ClienteReserva[] $clienteReservas
 * @property Telefone[] $telefones
 */
class Cliente extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'cliente';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['num_cliente', 'nome', 'dt_nascimento', 'rua', 'nPorta', 'cod_postal', 'num_cc', 'email', 'telefone', 'num_contribuinte'], 'required'],
            [['num_cliente', 'num_cc', 'telefone', 'num_contribuinte'], 'integer'],
            [['dt_nascimento'], 'safe'],
            [['nome', 'rua', 'email'], 'string', 'max' => 100],
            [['nPorta'], 'string', 'max' => 50],
            [['cod_postal'], 'string', 'max' => 20],
            [['num_cliente'], 'unique'],
            [['cod_postal'], 'exist', 'skipOnError' => true, 'targetClass' => Codpostal::className(), 'targetAttribute' => ['cod_postal' => 'codpostal']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'num_cliente' => 'Num Cliente',
            'nome' => 'Nome',
            'dt_nascimento' => 'Dt Nascimento',
            'rua' => 'Rua',
            'nPorta' => 'N Porta',
            'cod_postal' => 'Cod Postal',
            'num_cc' => 'Num Cc',
            'email' => 'Email',
            'telefone' => 'Telefone',
            'num_contribuinte' => 'Num Contribuinte',
        ];
    }

    /**
     * Gets query for [[CodPostal]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCodPostal()
    {
        return $this->hasOne(Codpostal::className(), ['codpostal' => 'cod_postal']);
    }

    /**
     * Gets query for [[ClienteReservas]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getClienteReservas()
    {
        return $this->hasMany(ClienteReserva::className(), ['num_cliente' => 'num_cliente']);
    }

    /**
     * Gets query for [[Telefones]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getTelefones()
    {
        return $this->hasMany(Telefone::className(), ['num_cliente' => 'num_cliente']);
    }
}
