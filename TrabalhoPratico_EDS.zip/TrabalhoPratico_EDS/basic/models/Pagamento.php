<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "pagamento".
 *
 * @property int $num_pagamento
 * @property string $tipo_pagamento
 * @property string $data
 * @property float $valor_pagar
 *
 * @property Reserva[] $reservas
 */
class Pagamento extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'pagamento';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['num_pagamento', 'tipo_pagamento', 'data', 'valor_pagar'], 'required'],
            [['num_pagamento'], 'integer'],
            [['data'], 'safe'],
            [['valor_pagar'], 'number'],
            [['tipo_pagamento'], 'string', 'max' => 200],
            [['num_pagamento'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'num_pagamento' => 'Num Pagamento',
            'tipo_pagamento' => 'Tipo Pagamento',
            'data' => 'Data',
            'valor_pagar' => 'Valor Pagar',
        ];
    }

    /**
     * Gets query for [[Reservas]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getReservas()
    {
        return $this->hasMany(Reserva::className(), ['num_pagamento' => 'num_pagamento']);
    }
}
