<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "alojamento_pacotes".
 *
 * @property int $cod_alojamento
 * @property int $cod_pacote
 *
 * @property Alojamento $codAlojamento
 * @property Pacotes $codPacote
 */
class AlojamentoPacotes extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'alojamento_pacotes';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['cod_alojamento', 'cod_pacote'], 'required'],
            [['cod_alojamento', 'cod_pacote'], 'integer'],
            [['cod_alojamento'], 'exist', 'skipOnError' => true, 'targetClass' => Alojamento::className(), 'targetAttribute' => ['cod_alojamento' => 'cod_alojamento']],
            [['cod_pacote'], 'exist', 'skipOnError' => true, 'targetClass' => Pacotes::className(), 'targetAttribute' => ['cod_pacote' => 'cod_pacote']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'cod_alojamento' => 'Cod Alojamento',
            'cod_pacote' => 'Cod Pacote',
        ];
    }

    /**
     * Gets query for [[CodAlojamento]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCodAlojamento()
    {
        return $this->hasOne(Alojamento::className(), ['cod_alojamento' => 'cod_alojamento']);
    }

    /**
     * Gets query for [[CodPacote]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCodPacote()
    {
        return $this->hasOne(Pacotes::className(), ['cod_pacote' => 'cod_pacote']);
    }
}
