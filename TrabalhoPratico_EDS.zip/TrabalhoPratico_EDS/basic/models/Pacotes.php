<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "pacotes".
 *
 * @property int $cod_pacote
 * @property string $nome
 * @property float $valor
 *
 * @property AlojamentoPacotes[] $alojamentoPacotes
 * @property AtividadesPacotes[] $atividadesPacotes
 * @property CidadePacotes[] $cidadePacotes
 * @property Reserva[] $reservas
 * @property TransportePacotes[] $transportePacotes
 */
class Pacotes extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'pacotes';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['cod_pacote', 'nome', 'valor'], 'required'],
            [['cod_pacote'], 'integer'],
            [['valor'], 'number'],
            [['nome'], 'string', 'max' => 100],
            [['cod_pacote'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'cod_pacote' => 'Cod Pacote',
            'nome' => 'Nome',
            'valor' => 'Valor',
        ];
    }

    /**
     * Gets query for [[AlojamentoPacotes]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getAlojamentoPacotes()
    {
        return $this->hasMany(AlojamentoPacotes::className(), ['cod_pacote' => 'cod_pacote']);
    }

    /**
     * Gets query for [[AtividadesPacotes]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getAtividadesPacotes()
    {
        return $this->hasMany(AtividadesPacotes::className(), ['cod_pacote' => 'cod_pacote']);
    }

    /**
     * Gets query for [[CidadePacotes]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCidadePacotes()
    {
        return $this->hasMany(CidadePacotes::className(), ['cod_pacote' => 'cod_pacote']);
    }

    /**
     * Gets query for [[Reservas]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getReservas()
    {
        return $this->hasMany(Reserva::className(), ['cod_pacote' => 'cod_pacote']);
    }

    /**
     * Gets query for [[TransportePacotes]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getTransportePacotes()
    {
        return $this->hasMany(TransportePacotes::className(), ['cod_pacote' => 'cod_pacote']);
    }
}
