<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "cliente_reserva".
 *
 * @property int $num_cliente
 * @property int $num_reserva
 * @property string $tipo_cliente
 *
 * @property Cliente $numCliente
 * @property Reserva $numReserva
 */
class ClienteReserva extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'cliente_reserva';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['num_cliente', 'num_reserva', 'tipo_cliente'], 'required'],
            [['num_cliente', 'num_reserva'], 'integer'],
            [['tipo_cliente'], 'string', 'max' => 200],
            [['num_cliente'], 'exist', 'skipOnError' => true, 'targetClass' => Cliente::className(), 'targetAttribute' => ['num_cliente' => 'num_cliente']],
            [['num_reserva'], 'exist', 'skipOnError' => true, 'targetClass' => Reserva::className(), 'targetAttribute' => ['num_reserva' => 'num_reserva']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'num_cliente' => 'Num Cliente',
            'num_reserva' => 'Num Reserva',
            'tipo_cliente' => 'Tipo Cliente',
        ];
    }

    /**
     * Gets query for [[NumCliente]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getNumCliente()
    {
        return $this->hasOne(Cliente::className(), ['num_cliente' => 'num_cliente']);
    }

    /**
     * Gets query for [[NumReserva]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getNumReserva()
    {
        return $this->hasOne(Reserva::className(), ['num_reserva' => 'num_reserva']);
    }
}
