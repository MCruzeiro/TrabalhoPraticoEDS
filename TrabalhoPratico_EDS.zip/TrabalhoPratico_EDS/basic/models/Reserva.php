<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "reserva".
 *
 * @property int $num_reserva
 * @property string $data
 * @property float $valor
 * @property string $dt_pagamento
 * @property string $estado_pagamento
 * @property int $num_pagamento
 * @property int $num_funcionario
 * @property int $cod_pacote
 *
 * @property ClienteReserva[] $clienteReservas
 * @property Pagamento $numPagamento
 * @property Funcionario $numFuncionario
 * @property Pacotes $codPacote
 */
class Reserva extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'reserva';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['num_reserva', 'data', 'valor', 'dt_pagamento', 'estado_pagamento', 'num_pagamento', 'num_funcionario', 'cod_pacote'], 'required'],
            [['num_reserva', 'num_pagamento', 'num_funcionario', 'cod_pacote'], 'integer'],
            [['data', 'dt_pagamento'], 'safe'],
            [['valor'], 'number'],
            [['estado_pagamento'], 'string', 'max' => 20],
            [['num_reserva'], 'unique'],
            [['num_pagamento'], 'exist', 'skipOnError' => true, 'targetClass' => Pagamento::className(), 'targetAttribute' => ['num_pagamento' => 'num_pagamento']],
            [['num_funcionario'], 'exist', 'skipOnError' => true, 'targetClass' => Funcionario::className(), 'targetAttribute' => ['num_funcionario' => 'num_funcionario']],
            [['cod_pacote'], 'exist', 'skipOnError' => true, 'targetClass' => Pacotes::className(), 'targetAttribute' => ['cod_pacote' => 'cod_pacote']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'num_reserva' => 'Num Reserva',
            'data' => 'Data',
            'valor' => 'Valor',
            'dt_pagamento' => 'Dt Pagamento',
            'estado_pagamento' => 'Estado Pagamento',
            'num_pagamento' => 'Num Pagamento',
            'num_funcionario' => 'Num Funcionario',
            'cod_pacote' => 'Cod Pacote',
        ];
    }

    /**
     * Gets query for [[ClienteReservas]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getClienteReservas()
    {
        return $this->hasMany(ClienteReserva::className(), ['num_reserva' => 'num_reserva']);
    }

    /**
     * Gets query for [[NumPagamento]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getNumPagamento()
    {
        return $this->hasOne(Pagamento::className(), ['num_pagamento' => 'num_pagamento']);
    }

    /**
     * Gets query for [[NumFuncionario]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getNumFuncionario()
    {
        return $this->hasOne(Funcionario::className(), ['num_funcionario' => 'num_funcionario']);
    }

    /**
     * Gets query for [[CodPacote]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCodPacote()
    {
        return $this->hasOne(Pacotes::className(), ['cod_pacote' => 'cod_pacote']);
    }
}
