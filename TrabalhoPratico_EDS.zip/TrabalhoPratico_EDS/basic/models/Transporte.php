<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "transporte".
 *
 * @property int $cod_transporte
 * @property float $valor
 * @property string $nome_companhia
 *
 * @property TransportePacotes[] $transportePacotes
 */
class Transporte extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'transporte';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['cod_transporte', 'valor', 'nome_companhia'], 'required'],
            [['cod_transporte'], 'integer'],
            [['valor'], 'number'],
            [['nome_companhia'], 'string', 'max' => 200],
            [['cod_transporte'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'cod_transporte' => 'Cod Transporte',
            'valor' => 'Valor',
            'nome_companhia' => 'Nome Companhia',
        ];
    }

    /**
     * Gets query for [[TransportePacotes]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getTransportePacotes()
    {
        return $this->hasMany(TransportePacotes::className(), ['cod_transporte' => 'cod_transporte']);
    }
}
