<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "cidade_pacotes".
 *
 * @property int $cod_cidade
 * @property int $cod_pacote
 *
 * @property Cidade $codCidade
 * @property Pacotes $codPacote
 */
class CidadePacotes extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'cidade_pacotes';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['cod_cidade', 'cod_pacote'], 'required'],
            [['cod_cidade', 'cod_pacote'], 'integer'],
            [['cod_cidade'], 'exist', 'skipOnError' => true, 'targetClass' => Cidade::className(), 'targetAttribute' => ['cod_cidade' => 'cod_cidade']],
            [['cod_pacote'], 'exist', 'skipOnError' => true, 'targetClass' => Pacotes::className(), 'targetAttribute' => ['cod_pacote' => 'cod_pacote']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'cod_cidade' => 'Cod Cidade',
            'cod_pacote' => 'Cod Pacote',
        ];
    }

    /**
     * Gets query for [[CodCidade]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCodCidade()
    {
        return $this->hasOne(Cidade::className(), ['cod_cidade' => 'cod_cidade']);
    }

    /**
     * Gets query for [[CodPacote]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCodPacote()
    {
        return $this->hasOne(Pacotes::className(), ['cod_pacote' => 'cod_pacote']);
    }
}
