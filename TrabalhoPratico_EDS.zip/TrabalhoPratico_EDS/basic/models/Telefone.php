<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "telefone".
 *
 * @property int $num_cliente
 * @property int $telefone
 * @property string $tipo_telefone
 *
 * @property Cliente $numCliente
 */
class Telefone extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'telefone';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['num_cliente', 'telefone', 'tipo_telefone'], 'required'],
            [['num_cliente', 'telefone'], 'integer'],
            [['tipo_telefone'], 'string', 'max' => 100],
            [['num_cliente'], 'exist', 'skipOnError' => true, 'targetClass' => Cliente::className(), 'targetAttribute' => ['num_cliente' => 'num_cliente']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'num_cliente' => 'Num Cliente',
            'telefone' => 'Telefone',
            'tipo_telefone' => 'Tipo Telefone',
        ];
    }

    /**
     * Gets query for [[NumCliente]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getNumCliente()
    {
        return $this->hasOne(Cliente::className(), ['num_cliente' => 'num_cliente']);
    }
}
