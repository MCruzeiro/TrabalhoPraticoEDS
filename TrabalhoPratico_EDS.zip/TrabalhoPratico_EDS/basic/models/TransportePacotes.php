<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "transporte_pacotes".
 *
 * @property int $cod_transporte
 * @property int $cod_pacote
 *
 * @property Pacotes $codPacote
 * @property Transporte $codTransporte
 */
class TransportePacotes extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'transporte_pacotes';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['cod_transporte', 'cod_pacote'], 'required'],
            [['cod_transporte', 'cod_pacote'], 'integer'],
            [['cod_pacote'], 'exist', 'skipOnError' => true, 'targetClass' => Pacotes::className(), 'targetAttribute' => ['cod_pacote' => 'cod_pacote']],
            [['cod_transporte'], 'exist', 'skipOnError' => true, 'targetClass' => Transporte::className(), 'targetAttribute' => ['cod_transporte' => 'cod_transporte']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'cod_transporte' => 'Cod Transporte',
            'cod_pacote' => 'Cod Pacote',
        ];
    }

    /**
     * Gets query for [[CodPacote]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCodPacote()
    {
        return $this->hasOne(Pacotes::className(), ['cod_pacote' => 'cod_pacote']);
    }

    /**
     * Gets query for [[CodTransporte]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCodTransporte()
    {
        return $this->hasOne(Transporte::className(), ['cod_transporte' => 'cod_transporte']);
    }
}
