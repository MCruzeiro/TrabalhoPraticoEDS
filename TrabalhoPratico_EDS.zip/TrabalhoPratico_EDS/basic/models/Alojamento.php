<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "alojamento".
 *
 * @property int $cod_alojamento
 * @property float $valor
 * @property string $rua
 * @property string $nPorta
 * @property string $cod_postal
 * @property string $nome
 * @property string $país
 *
 * @property Codpostal $codPostal
 * @property AlojamentoPacotes[] $alojamentoPacotes
 */
class Alojamento extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'alojamento';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['cod_alojamento', 'valor', 'rua', 'nPorta', 'cod_postal', 'nome', 'país'], 'required'],
            [['cod_alojamento'], 'integer'],
            [['valor'], 'number'],
            [['rua'], 'string', 'max' => 300],
            [['nPorta', 'país'], 'string', 'max' => 100],
            [['cod_postal'], 'string', 'max' => 20],
            [['nome'], 'string', 'max' => 200],
            [['cod_alojamento'], 'unique'],
            [['cod_postal'], 'exist', 'skipOnError' => true, 'targetClass' => Codpostal::className(), 'targetAttribute' => ['cod_postal' => 'codpostal']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'cod_alojamento' => 'Cod Alojamento',
            'valor' => 'Valor',
            'rua' => 'Rua',
            'nPorta' => 'N Porta',
            'cod_postal' => 'Cod Postal',
            'nome' => 'Nome',
            'país' => 'País',
        ];
    }

    /**
     * Gets query for [[CodPostal]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCodPostal()
    {
        return $this->hasOne(Codpostal::className(), ['codpostal' => 'cod_postal']);
    }

    /**
     * Gets query for [[AlojamentoPacotes]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getAlojamentoPacotes()
    {
        return $this->hasMany(AlojamentoPacotes::className(), ['cod_alojamento' => 'cod_alojamento']);
    }
}
