<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "atividades_pacotes".
 *
 * @property int $cod_atividade
 * @property int $cod_pacote
 *
 * @property Atividades $codAtividade
 * @property Pacotes $codPacote
 */
class AtividadesPacotes extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'atividades_pacotes';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['cod_atividade', 'cod_pacote'], 'required'],
            [['cod_atividade', 'cod_pacote'], 'integer'],
            [['cod_atividade'], 'exist', 'skipOnError' => true, 'targetClass' => Atividades::className(), 'targetAttribute' => ['cod_atividade' => 'cod_atividade']],
            [['cod_pacote'], 'exist', 'skipOnError' => true, 'targetClass' => Pacotes::className(), 'targetAttribute' => ['cod_pacote' => 'cod_pacote']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'cod_atividade' => 'Cod Atividade',
            'cod_pacote' => 'Cod Pacote',
        ];
    }

    /**
     * Gets query for [[CodAtividade]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCodAtividade()
    {
        return $this->hasOne(Atividades::className(), ['cod_atividade' => 'cod_atividade']);
    }

    /**
     * Gets query for [[CodPacote]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCodPacote()
    {
        return $this->hasOne(Pacotes::className(), ['cod_pacote' => 'cod_pacote']);
    }
}
