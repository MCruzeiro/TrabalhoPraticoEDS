<?php

namespace app\models;

use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\Reserva;

/**
 * ReservaSearch represents the model behind the search form of `app\models\Reserva`.
 */
class ReservaSearch extends Reserva
{
    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['num_reserva', 'num_pagamento', 'num_funcionario', 'cod_pacote'], 'integer'],
            [['data', 'dt_pagamento', 'estado_pagamento'], 'safe'],
            [['valor'], 'number'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Reserva::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'num_reserva' => $this->num_reserva,
            'data' => $this->data,
            'valor' => $this->valor,
            'dt_pagamento' => $this->dt_pagamento,
            'num_pagamento' => $this->num_pagamento,
            'num_funcionario' => $this->num_funcionario,
            'cod_pacote' => $this->cod_pacote,
        ]);

        $query->andFilterWhere(['like', 'estado_pagamento', $this->estado_pagamento]);

        return $dataProvider;
    }
}
