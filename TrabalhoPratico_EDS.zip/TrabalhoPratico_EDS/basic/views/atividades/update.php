<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Atividades */

$this->title = 'Update Atividades: ' . $model->cod_atividade;
$this->params['breadcrumbs'][] = ['label' => 'Atividades', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->cod_atividade, 'url' => ['view', 'id' => $model->cod_atividade]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="atividades-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
