<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Reserva */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="reserva-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'num_reserva')->textInput() ?>

    <?= $form->field($model, 'data')->textInput() ?>

    <?= $form->field($model, 'valor')->textInput() ?>

    <?= $form->field($model, 'dt_pagamento')->textInput() ?>

    <?= $form->field($model, 'estado_pagamento')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'num_pagamento')->textInput() ?>

    <?= $form->field($model, 'num_funcionario')->textInput() ?>

    <?= $form->field($model, 'cod_pacote')->textInput() ?>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
