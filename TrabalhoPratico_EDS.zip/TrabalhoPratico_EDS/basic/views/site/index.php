<?php

/* @var $this yii\web\View */

$this->title = 'TrabalhoEDS';
?>
<div class="site-index">

    <div class="jumbotron" style="padding: 2em;">
        <h1>Agência de Viagens</h1>

        <p class="lead">Reserva já as tuas próximas férias inesquecíveis!</p>

        <p><a class="btn btn-lg btn-success" href="http://localhost:8080/index.php?r=pacotes">Reservar Férias!</a></p>
    </div>

    <div class="body-content" style="display: flex;">
        <img src="https://thumbs.jusbr.com/filters:format(webp)/imgs.jusbr.com/publications/images/733fd6f52a27ddf434c6c591cf66bb1a" style="margin: 0 auto;">
    </div>
      
</div>
