<?php

/* @var $this yii\web\View */

use yii\helpers\Html;

$this->title = 'Sobre';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-about">
    <h1><?= Html::encode($this->title) ?></h1>

    <h3>
        Quem Somos?
    </h3>

    <p>
    Somos uma agência de viagens localizada no Norte de Portugal.
    </p>


    <h3>
        Como funciona o serviço?
    </h3>

    <p>
    Os nossos serviços funcionam através de pacotes e parcerias com os mais variados tipos de alojamentos/transportes.
    </p>

    <h3>
        Como faço uma reserva?
    </h3>

    <p>
    Para fazer uma reserva, o cliente pode dirigir-se à agência ou fazê-la através do nosso website.
    </p>

    <h3>
        Qual o preço dos pacotes?
    </h3>

    <p>
    Os nossos serviços são compostos por 2 tipos de pacotes: Pacote Simples e Pacote Premium.
    </p>
    <p>
    O Pacote Simples são 20€ enquanto que o Pacote Premium são 40€.
    </p>

    <h3>
        Como nos contactar?
    </h3>

    <p>
    Pode contactar-nos através dos nossos e-mails/números de telemóvel.
    </p>
</div>
